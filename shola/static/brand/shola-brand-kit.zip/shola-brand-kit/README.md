# SHOLA brand kit

Everything needed to post about SHOLA and send volunteers our way.

**Download it all:**
[shola-brand-kit.zip](https://github.com/michsethowusu/SHOLA/releases/latest/download/shola-brand-kit.zip)
· **Web page:** [shola.inkika.org/brand](https://shola.inkika.org/brand)
· **Link to share:** `shola.inkika.org`

Regenerate the artwork with `python3 brand/build.py`.

## What SHOLA is, in one line

A place where Ghanaians confirm translations of everyday words in their own
language — a handful of words a day, by email, on the phone.

Two minutes a day. No app to install, no account, no password.

## The one thing to ask people to do

**Go to shola.inkika.org and sign up in the language they speak best.**

That is the whole call to action. No download, no form beyond name, email and
which days suit them.

## Artwork

| File | Size | Use it for |
|------|------|-----------|
| `story-why` | 1080×1920 | WhatsApp Status, IG story, TikTok |
| `story-how` | 1080×1920 | WhatsApp Status — explains the two minutes |
| `story-ask` | 1080×1920 | For speakers of the other 83 languages |
| `square-why` | 1080×1080 | Instagram and Facebook feed |
| `square-ask` | 1080×1080 | Instagram and Facebook feed |
| `x-post` | 1600×900 | X |
| `facebook-link` | 1200×630 | Facebook link preview |
| `youtube-lowerthird` | 1920×1080 | YouTube overlay, lower third — transparent PNG |
| `youtube-sidepanel` | 1920×1080 | YouTube overlay, left panel — transparent PNG |
| `youtube-thumbnail` | 1280×720 | YouTube thumbnail |
| `avatar` | 1080×1080 | Profile picture |
| `wordmark-light` / `wordmark-dark` | 1200×400 | Logo on light or dark backgrounds |
| `logo-mark.svg` | vector | The Ɔ mark on its own |

**The YouTube overlays** are transparent PNGs sized to a 1920×1080 timeline.
Place one full-frame over your footage and it sits where it should: the lower
third leaves about 80% of the picture clear, the side panel about 60%, so you
stay visible while it is on screen.

## Colours

| | Hex | Where |
|--|-----|-------|
| Kente red | `#c0392b` | The Ɔ, buttons, links. One red, used sparingly |
| Ink | `#1a1815` | All text |
| Sand | `#faf7f2` | Backgrounds |
| Gold | `#d99b2b` | Highlights only — champions, the YouTube thumbnail |
| Forest | `#1a635a` | Agreement and success states |

## Type

**Bricolage Grotesque** (free, Google Fonts) for headlines, in Bold or
ExtraBold with tight letter spacing. Body text is the phone's own system font,
so it looks native and loads instantly.

## The name

**SHOLA** — Share Your Language. Always written with the open O:
**SHƆLA**, with the `Ɔ` in kente red. If your keyboard cannot type `Ɔ`, copy
it from here or write SHOLA in plain letters rather than substituting a zero or
an O with a slash.

## Captions to copy

Short, for WhatsApp Status and TikTok:

> Your language, checked by the people who speak it. Two minutes a day.
> shola.inkika.org

> Twi, Ewe, Ga, Dagbani. A few words a day and you help build a proper record
> of our languages. shola.inkika.org

Ghanaian Pidgin, for a more casual audience:

> You fit speak Twi, Ewe, Ga or Dagbani? Give am 2 minutes every day make we
> put your language for the record. shola.inkika.org

Longer, for Instagram, Facebook or a YouTube description:

> Ghanaian languages are missing from the tools we use every day — not because
> nobody speaks them, but because too little of them has been written down.
>
> SHOLA sends you a few English words a day with three possible translations in
> your language. You tap the one you would actually use, or type your own. When
> two speakers agree, that translation is recorded and released free for anyone
> building tools in our languages.
>
> It takes two minutes. No app, no password.
>
> Sign up: shola.inkika.org

For speakers of a language not yet open:

> SHOLA is collecting Twi, Ewe, Ga and Dagbani now — and 83 more Ghanaian
> languages are on the list. Add your name and they will email you the day
> yours opens. shola.inkika.org

**Local-language captions:** we have deliberately not written these. Copy in
Twi, Ewe, Ga or Dagbani should be written by a speaker, not translated by us —
getting it slightly wrong in a campaign about language accuracy would undercut
the whole point. If you write one, send it to michsethowusu@gmail.com and we will add
it here with credit.

## Hashtags

`#SHOLA` `#ShareYourLanguage` `#Inkika` `#Twi` `#Ewe` `#Ga` `#Dagbani`
`#GhanaianLanguages` `#AIforGhana`

## What to say

- **It is two minutes.** People assume volunteering means hours. It does not.
- **No app, no password.** A link arrives by email and it opens straight into
  the words.
- **The result is free for anyone to build on.** That is how a language earns
  its place in the apps, services and businesses Ghanaians use every day.

## Please do not

- **Say it pays.** It is volunteer work. Nobody is paid, and implying otherwise
  brings people who leave immediately.
- **Promise a language that is not open.** Only Twi, Ewe, Ga and Dagbani are
  collecting today. For the rest, say they can join the list.
- **Recolour or stretch the logo,** or set the wordmark in another typeface.
- **Ask for anything beyond the sign-up.** No phone numbers, no payment details,
  no group to join first.

## Questions people will ask

**Does it cost anything?** No, and it never will.

**How much time?** Around two minutes on the days you choose. About 1,000 words
over a year.

**What if I miss a day?** Nothing is lost. Those words come back in your next
email.

**What happens to my email?** It is used to send your daily words and nothing
else.

**What if I do not know a word?** Skip it. Somebody else will see it.

**Who owns the result?** It is public, under CC BY 4.0, credited to Inkika
and the volunteers.

## Contact

michsethowusu@gmail.com · [ghananlp.org](https://ghananlp.org)
